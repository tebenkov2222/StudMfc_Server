﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AspNetMvcAuthGuide.Migrations
{
    public partial class InitIdentity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
